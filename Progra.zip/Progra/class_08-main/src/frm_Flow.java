import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class frm_Flow extends JFrame {
    private JPanel pnl_Principal;
    private JButton btn_Boton_1;
    private JButton btn_Boton_02;
    private JTextField txt_Cedula;

    public frm_Flow() {
        btn_Boton_1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Botón 1");
                txt_Cedula.setText("Hola soy el botón 1");
            }
        });
        btn_Boton_02.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Botón 2");
                txt_Cedula.setText("Hola soy el botón 2");
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ejemplo de FlowLayout");
        frame.setSize(450,200);

        frame.setContentPane(new frm_Flow().pnl_Principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
