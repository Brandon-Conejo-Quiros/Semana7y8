import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class frm_Border extends JFrame {
    private JPanel pnl_Principal;
    private JButton btn_Norte;
    private JButton btn_Este;
    private JButton btn_Oeste;
    private JButton btn_Sur;
    private JButton btn_Centro;

    public frm_Border() {
        btn_Norte.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                muestraBotones(false, true, true, true, true);
            }
        });
        btn_Sur.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                muestraBotones(true, true, true, false, true);
            }
        });
        btn_Este.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                muestraBotones(true, false, true, true, true);
            }
        });
        btn_Oeste.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                muestraBotones(true, true, false, true, true);
            }
        });
        btn_Centro.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                muestraBotones(true, true, true, true, false);
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ejemplo de BorderLayout");
        frame.setSize(350,350);

        frame.setContentPane(new frm_Border().pnl_Principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    private void muestraBotones(boolean norte, boolean este, boolean oeste, boolean sur, boolean centro) {
        btn_Norte.setVisible(norte);
        btn_Este.setVisible(este);
        btn_Oeste.setVisible(oeste);
        btn_Sur.setVisible(sur);
        btn_Centro.setVisible(centro);
    }


}
