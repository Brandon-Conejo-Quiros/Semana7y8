package frm_Datos;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class frm_Datos extends JFrame {
    private JPanel pnl_Principal;
    private JPanel pnl_Datos;
    private JPanel pnl_Botones;
    private JLabel lbl_Cedula;
    private JLabel lbl_Nombre;
    private JLabel lbl_Apellido1;
    private JLabel lbl_Apellido2;
    private JLabel lbl_FechaNac;
    private JTextField txt_Cedula;
    private JTextField txt_Nombre;
    private JTextField txt_Apellido_1;
    private JTextField txt_Apellido_2;
    private JTextField txt_FechaNac;
    private JButton btn_Insertar;
    private JButton btn_Modificar;
    private JButton btn_Eliminar;
    private JButton btn_Salir;

    public frm_Datos() {
        super("Datos Personales");
        this.createUIComponents();

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setContentPane(pnl_Principal);

        this.setSize(400, 200);
        this.setExtendedState(JFrame.NORMAL);
        this.setResizable(false);
        this.setVisible(true);

        this.btn_Insertar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Insertar");
                insertar();
            }
        });

        this.btn_Modificar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Modificar");
                modificar();
            }
        });

        this.btn_Eliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Eliminar");
                eliminar();
            }
        });

        this.btn_Salir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(JOptionPane.showConfirmDialog(null, "¿Desea salir del programa?", "Salir", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION){
                    System.exit(0);
                }
            }
        });

        this.txt_Cedula.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buscar();
            }
        });

        this.iniInterface();
    }

    // Create the components
    private void createUIComponents() {
        // Create the panels
        pnl_Principal = new JPanel();
        pnl_Principal.setLayout(new BorderLayout());
        pnl_Principal.setPreferredSize(new Dimension(400,200));

        pnl_Datos = new JPanel();
        pnl_Datos.setLayout(new GridLayout(5, 2));
        pnl_Datos.setPreferredSize(new Dimension(400,125));
        pnl_Datos.setBorder(BorderFactory.createEmptyBorder(10,10,5,10));

        pnl_Botones = new JPanel();
        pnl_Botones.setLayout(new GridLayout(1, 4));
        pnl_Botones.setPreferredSize(new Dimension(400,75));
        pnl_Botones.setBorder(BorderFactory.createEmptyBorder(5,10,5,10));

        // Create the labels
        lbl_Cedula = new JLabel("Cédula:");
        lbl_Nombre = new JLabel("Nombre:");
        lbl_Apellido1 = new JLabel("Apellido 1:");
        lbl_Apellido2 = new JLabel("Apellido 2:");
        lbl_FechaNac = new JLabel("Fecha de Nacimiento:");

        // Create the text fields
        txt_Cedula = new JTextField();
        txt_Nombre = new JTextField();
        txt_Apellido_1 = new JTextField();
        txt_Apellido_2 = new JTextField();
        txt_FechaNac = new JTextField();

        // Create the buttons
        btn_Insertar = new JButton("Insertar");
        btn_Modificar = new JButton("Modificar");
        btn_Eliminar = new JButton("Eliminar");
        btn_Salir = new JButton("Salir");

        // Add the components to the panels
        pnl_Datos.add(lbl_Cedula);
        pnl_Datos.add(txt_Cedula);

        pnl_Datos.add(lbl_Nombre);
        pnl_Datos.add(txt_Nombre);

        pnl_Datos.add(lbl_Apellido1);
        pnl_Datos.add(txt_Apellido_1);

        pnl_Datos.add(lbl_Apellido2);
        pnl_Datos.add(txt_Apellido_2);

        pnl_Datos.add(lbl_FechaNac);
        pnl_Datos.add(txt_FechaNac);

        pnl_Botones.add(btn_Insertar);
        pnl_Botones.add(btn_Modificar);
        pnl_Botones.add(btn_Eliminar);
        pnl_Botones.add(btn_Salir);

        pnl_Principal.add(pnl_Datos,BorderLayout.PAGE_START);
        pnl_Principal.add(pnl_Botones, BorderLayout.CENTER);

        this.pack();
    }

    public static void main(String[] args) {
        new frm_Datos();
    }

    private void iniInterface(){
        btn_Insertar.setEnabled(false);
        btn_Modificar.setEnabled(false);
        btn_Eliminar.setEnabled(false);
        txt_Cedula.requestFocus();
    }

    private void buscar(){
        String cedula = txt_Cedula.getText();
        if(cedula.isEmpty()){
            JOptionPane.showMessageDialog(null, "Debe ingresar la cédula", "Error", JOptionPane.ERROR_MESSAGE);
            txt_Cedula.requestFocus();
        }else{
            if(cedula.length() != 9){
                JOptionPane.showMessageDialog(null, "La cédula debe tener 9 dígitos", "Error", JOptionPane.ERROR_MESSAGE);
                txt_Cedula.requestFocus();
            }else{
                // Buscar la cédula
                if(cedula.compareTo("123456789") == 0){
                    txt_Nombre.setText("Morticia");
                    txt_Apellido_1.setText("Addams");
                    txt_Apellido_2.setText("Frump");
                    txt_FechaNac.setText("1950-10-31");
                    btn_Insertar.setEnabled(false);
                    btn_Modificar.setEnabled(true);
                    btn_Eliminar.setEnabled(true);
                }else{
                    txt_Nombre.setText("");
                    txt_Apellido_1.setText("");
                    txt_Apellido_2.setText("");
                    txt_FechaNac.setText("");
                    btn_Insertar.setEnabled(true);
                    btn_Modificar.setEnabled(false);
                    btn_Eliminar.setEnabled(false);
                }
                txt_Nombre.requestFocus();
            }
        }
    }

    private void insertar(){
        String cedula = txt_Cedula.getText();
        String nombre = txt_Nombre.getText();
        String apellido1 = txt_Apellido_1.getText();
        String apellido2 = txt_Apellido_2.getText();
        String fechaNac = txt_FechaNac.getText();
        if(cedula.isEmpty() || nombre.isEmpty() || apellido1.isEmpty() || apellido2.isEmpty() || fechaNac.isEmpty()){
            JOptionPane.showMessageDialog(null, "Debe ingresar todos los datos", "Error", JOptionPane.ERROR_MESSAGE);
        }else{
            // Insertar los datos
            JOptionPane.showMessageDialog(null, "Datos insertados correctamente", "Información", JOptionPane.INFORMATION_MESSAGE);
            txt_Cedula.setText("");
            txt_Nombre.setText("");
            txt_Apellido_1.setText("");
            txt_Apellido_2.setText("");
            txt_FechaNac.setText("");
            txt_Cedula.requestFocus();
            btn_Insertar.setEnabled(false);
            btn_Modificar.setEnabled(false);
            btn_Eliminar.setEnabled(false);
        }
    }

    private void modificar(){
        String cedula = txt_Cedula.getText();
        String nombre = txt_Nombre.getText();
        String apellido1 = txt_Apellido_1.getText();
        String apellido2 = txt_Apellido_2.getText();
        String fechaNac = txt_FechaNac.getText();
        if(cedula.isEmpty() || nombre.isEmpty() || apellido1.isEmpty() || apellido2.isEmpty() || fechaNac.isEmpty()){
            JOptionPane.showMessageDialog(null, "Debe ingresar todos los datos", "Error", JOptionPane.ERROR_MESSAGE);
        }else{
            // Modificar los datos
            JOptionPane.showMessageDialog(null, "Datos modificados correctamente", "Información", JOptionPane.INFORMATION_MESSAGE);
            txt_Cedula.setText("");
            txt_Nombre.setText("");
            txt_Apellido_1.setText("");
            txt_Apellido_2.setText("");
            txt_FechaNac.setText("");
            txt_Cedula.requestFocus();
            btn_Insertar.setEnabled(false);
            btn_Modificar.setEnabled(false);
            btn_Eliminar.setEnabled(false);
        }
    }

    private void eliminar(){
        String cedula = txt_Cedula.getText();
        if(cedula.isEmpty()){
            JOptionPane.showMessageDialog(null, "Debe ingresar la cédula", "Error", JOptionPane.ERROR_MESSAGE);
            txt_Cedula.requestFocus();
        }else{
            // Eliminar los datos
            JOptionPane.showMessageDialog(null, "Datos eliminados correctamente", "Información", JOptionPane.INFORMATION_MESSAGE);
            txt_Cedula.setText("");
            txt_Nombre.setText("");
            txt_Apellido_1.setText("");
            txt_Apellido_2.setText("");
            txt_FechaNac.setText("");
            txt_Cedula.requestFocus();
            btn_Insertar.setEnabled(false);
            btn_Modificar.setEnabled(false);
            btn_Eliminar.setEnabled(false);
        }
    }
}
