--1.Listar juegos disponibles

SELECT * FROM Juegos

--2.Listar todos los clientes

SELECT * FROM Clientes

--3.Encontrar juegos aptos para ni�os de 5 a�os

SELECT * FROM Juegos WHERE EdadRecomendada = 5

--4.Listar reservas hechas por clientes

SELECT * FROM Reservas

--5.Mostrar los nombres de los clientes y los juegos que reservaron


SELECT 
	C.Nombre AS NombreCliente,
    J.Nombre AS NombreJuego
FROM 
    Reservas R
JOIN 
    Juegos J ON R.JuegoID = J.JuegoID
JOIN 
    Clientes C ON R.ClienteID = C.ClienteID




--6.Encontrar clientes en juego "carrusel"


SELECT 
	C.Nombre AS NombreCliente,
    J.Nombre AS NombreJuego
FROM 
    Reservas R
JOIN 
    Juegos J ON R.JuegoID = J.JuegoID
JOIN 
    Clientes C ON R.ClienteID = C.ClienteID
WHERE J.Nombre = 'Carrusel'


--7.Contar el numero total de juegos
--TECNICAMENTE EST� CONTADO
--Dice el numero total de juegos. Y hasta lo dice en orden
SELECT [JuegoID] FROM Juegos


--8.Listar reservas hechas en una fecha especifica

SELECT * FROM Reservas WHERE Fecha = '2024-08-15';

--9.Listar el nombre de los juegos ordenados alfabeticamente

SELECT * FROM Juegos ORDER BY Nombre ASC

--10.Listar los nombres de todos los clientes ordenados por edad de mayor a menor

SELECT Nombre FROM Clientes ORDER BY Edad ASC

--11.Mostrar los nombres de los juegos y sus respectivas capacidades maximas

SELECT 
Nombre,
CapacidadMaxima
FROM 
Juegos

--12.Mostrar los juegos con capacidad maxima de al menos 15 personas
SELECT
Nombre,
CapacidadMaxima
FROM Juegos
WHERE CapacidadMaxima >= 15

--13.Mostrar los clientes que han reservado un juego en una fecha especifica
SELECT 
	C.Nombre AS NombreCliente,
	R.Fecha
FROM 
    Reservas R
JOIN 
    Clientes C ON R.ClienteID = C.ClienteID
WHERE R.Fecha = '2024-08-15';

--14.Mostrar los nombres de los juegos recomendados para ni�os de 7 a�os o m�s

SELECT
Nombre,
EdadRecomendada
FROM Juegos
WHERE EdadRecomendada >= 7

--15.Listar los nombres de los clientes y las fechas en las que se hicieron sus reservas

SELECT 
	C.Nombre AS NombreCliente,
	R.Fecha
FROM 
    Reservas R
JOIN 
    Clientes C ON R.ClienteID = C.ClienteID