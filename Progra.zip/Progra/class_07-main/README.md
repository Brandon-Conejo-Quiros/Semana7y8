### General Instructions

Create the database and tables for the project.
* Init yours Database engines (Microsoft SQL-Server or MySQL or both).
* Connect to the database engine, and using Management Studio or Workbench.
* Open the data folder and execute the script for each database engine.

