package connections;

// Call external libraries
import java.sql.*;

public class conex_MySQL {
    // Create the connection variables
    private Connection conex = null;
    private ResultSet rs = null;

    // Create the connection string
    private String dbURL = "jdbc:mysql://localhost:3306/db_ejemplo";
    private String user = "root";
    private String pass = "parda99*";

    // Create the connection method
    public Connection toConnect() throws SQLException {
        // Try to connect to the database
        try {
            DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
            conex = DriverManager.getConnection(dbURL, user, pass);
            if (conex != null) {
                conex.setAutoCommit(true);
                System.out.println("Connected to the database...!\n");
            }
        }catch (SQLException e){
            throw new SQLException("Error: " + e.getMessage());
        }
        return conex;
    }

    // Create the disconnection method
    public void toDisConnect() throws SQLException{
        try {
            if (rs != null) {
                rs.close();
            }
            if (conex != null) {
                conex.close();
            }
            System.out.println("Disconnected from the database...!\n");
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
