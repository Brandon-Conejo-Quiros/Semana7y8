package connections;

// Call external libraries
import java.sql.*;

public class conex_MSSQL {
    // Create the connection variables
    private Connection conex = null;
    private ResultSet rs = null;

    // Create the connection string
    private String dbURL = "jdbc:sqlserver://Orion:1433;databaseName=db_ejemplo;encrypt=false";
    private String user = "sa";
    private String pass = "Parda99*";

    // Create the connection method
    public Connection toConnect() throws SQLException {
        // Try to connect to the database
        try {
            DriverManager.registerDriver(new com.microsoft.sqlserver.jdbc.SQLServerDriver());
            conex = DriverManager.getConnection(dbURL, user, pass);
            if (conex != null) {
                conex.setAutoCommit(true);
                System.out.println("Connected to the database...!\n");
            }
        }catch (SQLException e){
            throw new SQLException("Error: " + e.getMessage());
        }
        return conex;
    }

    // Create the disconnection method
    public void toDisConnect() throws SQLException{
        try {
            if (rs != null) {
                rs.close();
            }
            if (conex != null) {
                conex.close();
            }
            System.out.println("Disconnected from the database...!\n");
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

}
